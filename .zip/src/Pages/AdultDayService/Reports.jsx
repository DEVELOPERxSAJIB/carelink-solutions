
const Reports = () => {
  return <div>Reports</div>;
};

export default Reports;
