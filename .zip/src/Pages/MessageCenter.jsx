
const MessageCenter = () => {
  return <div>MessageCenter</div>;
};

export default MessageCenter;
