
const Help = () => {
  return <div>Help</div>;
};

export default Help;
