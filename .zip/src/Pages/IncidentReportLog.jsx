
const IncidentReportLog = () => {
  return <div>IncidentReportLog</div>;
};

export default IncidentReportLog;
