
const SharedEvents = () => {
  return <div>SharedEvents</div>;
};

export default SharedEvents;
