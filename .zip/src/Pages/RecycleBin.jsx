
const RecycleBin = () => {
  return <div>RecycleBin</div>;
};

export default RecycleBin;
